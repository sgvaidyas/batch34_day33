﻿var a = []
var count = 0;
function addprod() {
    var pname = document.getElementById("pname").value;
    var price = document.getElementById("price").value;

    ob = { Prodname: pname, Prodprice: price };
    //console.log(ob);
    
    a.push(ob)
    // console.log(a)
    document.getElementById("pname").value = "";
    document.getElementById("price").value = 0;

}

function start() {
    var table = document.getElementById("showproducts");

    tr = table.insertRow();
    th = document.createElement('th')
    th.innerHTML = "PNAME"
    tr.appendChild(th);
    th1 = document.createElement('th')
    th1.innerHTML = "PRICE"
    tr.appendChild(th1);

    table.appendChild(tr)
}

function showprod() {
    var table = document.getElementById("showproducts");

    count++;
    if (count == 1)
        start()


    var arrlen = a.length;
    var rowCount = arrlen;
    for (var i = 0; i < arrlen; i++) {

        var tr = table.insertRow();
        var td = document.createElement('td')
        td.innerHTML = a[i].Prodname
        tr.appendChild(td)
        var td = document.createElement('td')
        td.innerHTML = a[i].Prodprice
        tr.appendChild(td)

        table.append(tr)
   
    }  
}