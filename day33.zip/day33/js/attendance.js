﻿var countabsentees = 0;
var absentlist=[]
function fun(num) {
    if (document.getElementById(num).style.backgroundColor == "pink") {

        document.getElementById(num).style.backgroundColor = "goldenrod";
        document.getElementById(num).style.color = "azure";
        countabsentees--;
        ind = absentlist.indexOf(document.getElementById(num).innerHTML)
        absentlist.splice(ind, 1)
        console.log(absentlist)

    }
    else {
        document.getElementById(num).style.backgroundColor = "pink";
        document.getElementById(num).style.color = "red";
        countabsentees++;
        absentlist.push(document.getElementById(num).innerHTML)
    }
}
function showdetails() {
    document.getElementById("absenteesno").innerHTML = "NO OF ABSENTEES : " + countabsentees;
    var eles = document.getElementById("stulist").getElementsByTagName('li'); 
    var presentnum = eles.length - countabsentees
    document.getElementById("presentno").innerHTML = "NO OF STU PRESENT : " + presentnum 
    document.getElementById("absentlist").innerHTML = "Absent students = " + absentlist
    
}